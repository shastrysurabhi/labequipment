import React from 'react';
import './../App.css';

class Header extends React.Component {
	constructor(props) {
		super(props);
	}
	
	render() {
    return (
      <header className="App-header"> Lab Equipments</header>
    );
  }
	
}

export default Header