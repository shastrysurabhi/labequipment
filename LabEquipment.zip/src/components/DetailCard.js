import React from 'react';
import './../App.css';

const DetailCard = () => (
    <div>
        <ul>
            {console.log('1. IN DETAILS')}
        </ul>
    </div>
);

export default DetailCard