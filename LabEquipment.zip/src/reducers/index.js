import Constants from '../appConstants';

const  EQUIPMENT_DETAILS = [{
    'Image': 'Image Value',
    'Equipment Name': 'Equipment 1',
    'Vendor': 'Vendor 1',
    'Location': 'Location 1',
    'Model': 'Model 1',
    'Serial Number': '001',
    'Description': 'Description 1'
},
    {
        'Image': 'Image Value 2',
        'Equipment Name': 'Equipment 2',
        'Vendor': 'Vendor 2',
        'Location': 'Location 2',
        'Model': 'Model 2',
        'Serial Number': '002',
        'Description': 'Description 2'
    }
];

const initialState = {
    selectedEquipment: '',
    detailsObject: EQUIPMENT_DETAILS
};

const displayDetailsReducer = (state = [], action) => {
    switch (action.type) {
        case 'DISPLAY_DETAIL':
            return [
                ...state,
                {
                    selectedEquipment: action.equipmentDetail
                }
            ];
        default:
            return state
    }
};

export default displayDetailsReducer