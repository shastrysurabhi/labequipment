const display = equipmentDetail => ({
    type: 'DISPLAY_DETAIL',
    equipmentDetail
});

export default display