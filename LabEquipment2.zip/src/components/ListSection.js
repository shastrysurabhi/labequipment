import React from 'react';
import display from '../actions/index';

import { EQUIPMENT_DETAILS } from '../appConstants';
import {connect} from "react-redux";
import mapStateToProps from "react-redux/es/connect/mapStateToProps";

const names = ['Equipment 1', 'Equipment 2'];

const items = names.map((eachObject) => {
    return <li key={eachObject} onClick={()=> display(eachObject)}> {eachObject} </li>
});

const ListSection = () => (
    <div className="list">
        <ul>
            <div>SYSTEMS</div>
            <div>DEVICE NAME</div>
            {items}
        </ul>
    </div>
);

export default ListSection

/*
const mapDispatchToProps = (dispatch, ownProps) => ({
    display: () => dispatch(display(ownProps.equipmentDetail))
});

export default connect(
    null,
    mapDispatchToProps
)(ListSection)
*/
