import { connect } from 'react-redux'
import display from 'src/actions/index'
import ListSection from 'src/components/ListSection'


const mapDispatchToProps = (dispatch, ownProps) => ({
    display: () => dispatch(display(ownProps.equipmentDetail))
});

export default connect(
    null,
    mapDispatchToProps
)(ListSection)
