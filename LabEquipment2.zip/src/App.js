import React from 'react';
import Header from './components/Header';
import './App.css';
import Footer from './components/Footer';
import BreadCrumb from './components/BreadCrumb';
import DetailCard from './components/DetailCard';
import ListSection from './components/ListSection';

function App() {
  return (
    <div className="App">
		<Header></Header>
		<BreadCrumb></BreadCrumb>
		<div className="content">
			<div className="content-inside">
				<DetailCard/>
				<ListSection></ListSection>
			</div>
		</div>
		<Footer></Footer>
    </div>
  );
}

export default App;
