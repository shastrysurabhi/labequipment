import React from 'react';
import './../App.css';

class BreadCrumb extends React.Component {
	constructor(props) {
		super(props);
	}
	
	render() {
    return (
		<ul className="breadcrumb">
			<li><a href="#">Home</a></li>
			<li><a href="#">Device Name</a></li>
			<li><a href="#">Equipment</a></li>
		</ul>
    );
  }
	
}

export default BreadCrumb